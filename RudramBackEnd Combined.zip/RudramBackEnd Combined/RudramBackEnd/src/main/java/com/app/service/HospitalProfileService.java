package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.Repo.HospitalRepository;
import com.app.entity.HospitalProfile;

@Service
public class HospitalProfileService {
	  @Autowired
	    private HospitalRepository hospitalRepository;

	    public HospitalProfile saveProfile(HospitalProfile hProfile) {
	        return hospitalRepository.save(hProfile);
	    }

	    public List<HospitalProfile> getAllProfiles() {
	        return hospitalRepository.findAll();
	    }

	    public HospitalProfile getProfileById(Long id) {
	        return hospitalRepository.findById(id).orElse(null);
	    }

	    public void deleteProfile(Long id) {
	        hospitalRepository.deleteById(id);
	    }

}
