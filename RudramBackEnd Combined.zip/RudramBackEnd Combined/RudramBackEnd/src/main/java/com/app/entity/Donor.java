package com.app.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Donor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String phoneNumber;
    private String name;
    private int age;
    private String bloodType;
    private LocalDate donationDate;
    
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
    
	public Donor() {
		super();
	}
	
	
	public Donor(Long id, String phoneNumber, String name, int age, String bloodType, LocalDate donationDate) {
		super();
		this.id = id;
		this.phoneNumber = phoneNumber;
		this.name = name;
		this.age = age;
		this.bloodType = bloodType;
		this.donationDate = donationDate;
	}


	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBloodType() {
		return bloodType;
	}
	public void setBloodType(String bloodType) {
		this.bloodType = bloodType;
	}
	public LocalDate getDonationDate() {
		return donationDate;
	}
	public void setDonationDate(LocalDate localDate) {
		this.donationDate = localDate;
	}
    
	public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
    
}